
# README.md

A snake game built on the Nexys A7 100T FPGA by Louis Turriaga, Jordan Tejada, Triet Vo, and James Hamm.

